<?php
/*
Plugin Name: درگاه پرداخت انلاين
Version: 2.5.0
Requires at least: 4.0
Description: افزونه درگاه پرداخت آنلاين براي وب سايت
Plugin URI: http://www.wordpress.org
Author: وردپرس
Author URI: http://www.wordpress.org
License: GPL 2
*/

@session_start();	
if ( ! defined( 'ABSPATH' ) ) exit;

if ( ! class_exists( 'EDD_sn_Direct_Gateway' ) ) :


class EDD_sn_Direct_Gateway {

	public $keyname;


	public function __construct() {
		$this->keyname = 'sn_Direct';

		add_filter( 'edd_payment_gateways', array( $this, 'add' ) );
		add_action( $this->format( 'edd_{key}_cc_form' ), array( $this, 'cc_form' ) );
		add_action( $this->format( 'edd_gateway_{key}' ), array( $this, 'process' ) );
		add_action( $this->format( 'edd_verify_{key}' ), array( $this, 'verify' ) );
		add_filter( 'edd_settings_gateways', array( $this, 'settings' ) );

		add_action( 'edd_payment_receipt_after', array( $this, 'receipt' ) );

		add_action( 'init', array( $this, 'listen' ) );
	}


	public function add( $gateways ) {
		global $edd_options;

		$gateways[ $this->keyname ] = array(
			'checkout_label' 		=>	isset( $edd_options['sn_Direct_label'] ) ? $edd_options['sn_Direct_label'] : 'پرداخت آنلاين',
			'admin_label' 			=>	'درگاه پرداخت'
		);

		return $gateways;
	}


	public function cc_form() {
		return;
	}


	public function process( $purchase_data ) {
		global $edd_options;
		$payment = $this->insert_payment( $purchase_data );

		if ( $payment ) {
		


			$_SESSION['sn_Direct_payment'] = $payment;
			EDD()->session->set( 'sn_Direct_payment_edd', $payment );
			set_transient( 'sn_Direct_payment_transient', $payment, 60*60*12 );
			
			
			$api = ( isset( $edd_options[ $this->keyname . '_api' ] ) ? $edd_options[ $this->keyname . '_api' ] : '' );
			
			if ( edd_get_currency() == 'IRT' || $edd_options['currency'] == 'IRT' ) {
				$amount = intval($purchase_data['price']);
			} else {
				$amount = intval($purchase_data['price']) / 10;
			}

			$desc = 'پرداخت شماره #' . $payment;
			
// Security
$sec = uniqid();
$md = md5($sec.'vm');
// Security
			$callback = add_query_arg( array('verify_' . $this->keyname => '1' ,'pid'=>$payment ,'md'=>$md ,'sec'=>$sec) , get_permalink( $edd_options['success_page'] ) );

			
			
$data_string = json_encode(array(
'pin'=> $api,
'price'=> $amount,
'callback'=> $callback ,
'order_id'=> $payment,
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);

			
			if(!empty($json['result']) AND $json['result'] == 1)
			{
// Set Session
$_SESSION[$sec] = [
	'price'=>$amount ,
	'order_id'=>$payment ,
];
$_SESSION[$sec]['au'] = $json['au']; //SET AU Session
				
				EDD()->session->set( 'sn_Direct_au', $json['au'] );
				edd_update_payment_meta( $payment, 'sn_Direct_au', $json['au'] );
				
				edd_insert_payment_note( $payment, ' شناسه = ' . $payment . '| شناسه پیگیری = ' . $json['au'] );
				echo "<div style='display:none'>{$json['form']}</div>Please wait ... <script language='javascript'>document.payment.submit(); </script>";
			} else {
				edd_insert_payment_note( $payment, 'کدخطا : ' . $json['result'] );
				edd_insert_payment_note( $payment, 'علت خطا : ' . $res['msg']  );
				edd_update_payment_status( $payment, 'failed' );
				edd_set_error( 'sn_Direct_connect_error', 'در اتصال به درگاه مشکلی پیش آمد. علت : ' . $json['msg']  );
				edd_send_back_to_checkout();
				exit;
			}
		} else {
			edd_send_back_to_checkout( '?payment-mode=' . $purchase_data['post_data']['edd-gateway'] );
			exit;
		}
	}

	
	public function verify() {
		global $edd_options;

		
		$session = edd_get_purchase_session();
		$payment = edd_get_purchase_id_by_key( $session['purchase_key'] );
				
		if ( isset( $_GET['pid'] ) && is_numeric($_GET['pid']) ) 
			$payment_id = $_GET['pid'];
		elseif ( EDD()->session->get( 'sn_payment_edd' ))
			$payment_id = EDD()->session->get( 'sn_payment_edd' );
		elseif ($payment)
			$payment_id = $payment;
		elseif ($_SESSION['sn_payment'])
			$payment_id = $_SESSION['sn_payment'];
		else
			$payment_id = get_transient( 'sn_payment_transient' );
		delete_transient( 'sn_payment_transient' );
				
		if ( ! $payment_id ) {
			wp_die( 'رکورد پرداخت موردنظر وجود ندارد!' );
		}

			
		$amount = intval( edd_get_payment_amount( $payment_id ) );
		if ( edd_get_currency() == 'IRT' || $edd_options['currency'] == 'IRT' ) 
			$amount = $amount;
		else
			$amount = $amount / 10;					

		$api = ( isset( $edd_options[ $this->keyname . '_api' ] ) ? $edd_options[ $this->keyname . '_api' ] : '' );

		$authority = edd_get_payment_meta( $payment_id, 'sn_Direct_au' );
		if ( ! $authority )
			$authority = EDD()->session->get( 'sn_Direct_au' );
		

			
		if ( version_compare( EDD_VERSION, '2.1', '>=' ) )
			edd_set_payment_transaction_id( $payment_id, $authority );
			
			
// Security
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');

// Security
//get data from session
$transData = $_SESSION[$sec];
$au=$transData['au']; //			
			
		if ( !empty($au) ) {
			edd_update_payment_meta( $payment_id, 'sn_bank_au', $au );
			edd_insert_payment_note( $payment_id, 'رسید دیجیتال : ' . $au );
		}
		
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $api,
'price' => $amount,
'order_id' => $payment_id,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$mdurl=$_GET['md'];
	

	
	if($mdback == $mdurl)
	{
 //result
 $json = json_decode($result,true);
				$result = $json['result'];
			
		if ( ! empty( $result ) && intval( $result ) == 1 ) {
			edd_insert_payment_note( $payment_id, 'پرداخت موفقیت آمیز بود . شماره تراکنش : ' . $authority );
			edd_empty_cart();
			edd_update_payment_status( $payment_id, 'publish' );
			edd_send_to_success_page();
			exit;
	
		} else {
			edd_insert_payment_note( $payment_id, 'کد خطا : ' . $result );
			edd_insert_payment_note( $payment_id, 'علت خطا : ' . $this->error_reason($result) );
			edd_update_payment_status( $payment_id, 'failed' );
			wp_redirect( get_permalink( $edd_options['failure_page'] ) );
			exit;
		}
		
	
	} else {
			edd_insert_payment_note( $payment_id, 'خطای امنیتی !!!' );
			edd_update_payment_status( $payment_id, 'failed' );
			wp_redirect( get_permalink( $edd_options['failure_page'] ) );
			exit;
		}
	}

	public function receipt( $payment ) {
		$refid = edd_get_payment_meta( $payment->ID, 'sn_Direct_au' );
		if ( $refid ) {
			echo '<tr class="sn_Direct-ref-id-row iranian-gateway-field"><td><strong>شماره تراکنش :</strong></td><td>' . $refid . '</td></tr>';
		}
		
		$bank_au = edd_get_payment_meta( $payment->ID, 'sn_bank_au' );
		if ( $refid ) {
			echo '<tr class="sn_Direct-ref-id-row iranian-gateway-field"><td><strong>رسید دیجیتال :</strong></td><td>' . $bank_au . '</td></tr>';
		}
		
	}


	public function settings( $settings ) {
		return array_merge( $settings, array(
			$this->keyname . '_header' 		=>	array(
				'id' 			=>	$this->keyname . '_header',
				'type' 			=>	'header',
				'name' 			=>	'<strong>درگاه پرداخت آنلاين</strong>'
			),
			$this->keyname . '_api' 		=>	array(
				'id' 			=>	$this->keyname . '_api',
				'name' 			=>	'API',
				'type' 			=>	'text',
				'size' 			=>	'regular'
			),
			$this->keyname . '_label' 	=>	array(
				'id' 			=>	$this->keyname . '_label',
				'name' 			=>	'نام درگاه در صفحه پرداخت',
				'type' 			=>	'text',
				'size' 			=>	'regular',
				'std' 			=>	'درگاه پرداخت آنلاين'
			)
		) );
	}


	private function format( $string ) {
		return str_replace( '{key}', $this->keyname, $string );
	}


	private function insert_payment( $purchase_data ) {
		global $edd_options;

		$payment_data = array( 
			'price' => $purchase_data['price'], 
			'date' => $purchase_data['date'], 
			'user_email' => $purchase_data['user_email'],
			'purchase_key' => $purchase_data['purchase_key'],
			'currency' => $edd_options['currency'],
			'downloads' => $purchase_data['downloads'],
			'user_info' => $purchase_data['user_info'],
			'cart_details' => $purchase_data['cart_details'],
			'status' => 'pending'
		);

	
		$payment = edd_insert_payment( $payment_data );

		return $payment;
	}


	public function listen() {
		if ( isset( $_GET[ 'verify_' . $this->keyname ] ) && $_GET[ 'verify_' . $this->keyname ] ) {
			do_action( 'edd_verify_' . $this->keyname );
		}
	}



	
}

endif;

new EDD_sn_Direct_Gateway;

if ( !function_exists( 'edd_rial' ) ) {
	function edd_rial( $formatted, $currency, $price ) {
		return $price . ' ریال'; }
	add_filter( 'edd_rial_currency_filter_after', 'edd_rial', 10, 3 );
}